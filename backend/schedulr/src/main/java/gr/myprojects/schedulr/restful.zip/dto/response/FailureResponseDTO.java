package gr.myprojects.schedulr.dto.response;

import lombok.*;
import org.springframework.http.HttpStatus;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class FailureResponseDTO {
    private HttpStatus status;
    private String code;
    private String message;
    private Object extraInformation;
}
