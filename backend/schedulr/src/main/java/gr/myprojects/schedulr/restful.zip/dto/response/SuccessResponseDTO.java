package gr.myprojects.schedulr.dto.response;

import lombok.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class SuccessResponseDTO<T> {
    private HttpStatus status;
    private T data;
}
