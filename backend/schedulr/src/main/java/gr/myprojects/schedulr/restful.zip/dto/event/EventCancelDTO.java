package gr.myprojects.schedulr.dto.event;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class EventCancelDTO {
    private String eventUuid;
    private String userUuid;
}
