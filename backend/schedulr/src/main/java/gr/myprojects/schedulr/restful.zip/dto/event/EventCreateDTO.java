package gr.myprojects.schedulr.dto.event;

import gr.myprojects.schedulr.core.enums.Category;
import gr.myprojects.schedulr.core.enums.Status;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class EventCreateDTO {

    @NotEmpty
    @Size(max = 255)
    private String title;

    @NotEmpty
    @Size(max = 1000)
    private String description;

    @NotNull
    private LocalDateTime date;

    @NotEmpty
    private String location;

    @NotNull
    @Min(0)
    private Double price;

    @NotNull
    @Min(0)
    private Integer maxSeats;

    @NotNull
    private Category category;
}
