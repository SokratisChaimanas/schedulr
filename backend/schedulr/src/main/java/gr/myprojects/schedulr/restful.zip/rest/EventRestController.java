package gr.myprojects.schedulr.rest;

import gr.myprojects.schedulr.core.enums.Status;
import gr.myprojects.schedulr.core.exceptions.*;
import gr.myprojects.schedulr.core.filters.Paginated;
import gr.myprojects.schedulr.dto.event.*;
import gr.myprojects.schedulr.dto.response.SuccessResponseDTO;
import gr.myprojects.schedulr.service.EventService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.util.List;

@RestController
@RequestMapping("/api/events")
@RequiredArgsConstructor
public class EventRestController {
    private final EventService eventService;

    @PostMapping("/create")
    public ResponseEntity<SuccessResponseDTO<EventReadOnlyDTO>> createEvent(
            @Valid @RequestPart("createDTO") EventCreateDTO createDTO,
            @RequestPart("uuid") String uuid,
            @RequestPart(name = "imageFile", required = false)MultipartFile imageFile,
            BindingResult bindingResult)
            throws ValidationException, AppObjectInvalidArgumentException,
            AppObjectNotFoundException, IOException, AppServerException {
        System.out.println("I HAVE ACCESSED THE CONTROLLER");
        if (bindingResult.hasErrors()) {
            throw new ValidationException("ImageAttachment", bindingResult);
        }

//        MultipartFile imageFile = null;
        EventReadOnlyDTO readOnlyDTO = eventService.saveEvent(createDTO, uuid, imageFile);
        SuccessResponseDTO<EventReadOnlyDTO> successResponseDTO = SuccessResponseDTO.<EventReadOnlyDTO>builder()
                .status(HttpStatus.CREATED)
                .data(readOnlyDTO)
                .build();

        return new ResponseEntity<>(successResponseDTO, HttpStatus.CREATED);
    }

    @PutMapping("/cancel")
    public ResponseEntity<SuccessResponseDTO<EventReadOnlyDTO>> cancelEvent(
            @RequestBody EventCancelDTO cancelDTO
            ) throws AppObjectNotFoundException, AccessDeniedException, AppServerException {
        EventReadOnlyDTO eventReadOnlyDTO = eventService.cancelEvent(cancelDTO.getEventUuid(), cancelDTO.getUserUuid());

        SuccessResponseDTO<EventReadOnlyDTO> successResponseDTO = SuccessResponseDTO.<EventReadOnlyDTO>builder()
                .status(HttpStatus.OK)
                .data(eventReadOnlyDTO)
                .build();

        return new ResponseEntity<>(successResponseDTO, HttpStatus.OK);
    }


    @PostMapping("/attend")
    public ResponseEntity<SuccessResponseDTO<EventReadOnlyDTO>> attendEvent(
            @RequestBody EventAttendDTO eventAttendDTO
            ) throws AppObjectNotFoundException, AccessDeniedException, EventFullException, AppObjectUnavailableException, AppObjectInvalidArgumentException, AppServerException {
        // Log the method entry (optional for debugging)
        System.out.println("I HAVE ACCESSED THE ATTEND EVENT CONTROLLER");

        EventReadOnlyDTO readOnlyDTO = eventService.attendEvent(eventAttendDTO);

        SuccessResponseDTO<EventReadOnlyDTO> successResponseDTO = SuccessResponseDTO.<EventReadOnlyDTO>builder()
                .status(HttpStatus.OK)
                .data(readOnlyDTO)
                .build();

        return new ResponseEntity<>(successResponseDTO, HttpStatus.OK);
    }

    @GetMapping("")
    public ResponseEntity<SuccessResponseDTO<Page<EventReadOnlyDTO>>> getPaginatedEvents(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "PENDING") Status status // Default to PENDING if no status is provided
    ) {
        // Fetch events based on the given status
        Page<EventReadOnlyDTO> events = eventService.getPaginatedEventsByStatus(status, page, size);

        // Wrap the results in a SuccessResponseDTO
        SuccessResponseDTO<Page<EventReadOnlyDTO>> successResponseDTO = SuccessResponseDTO.<Page<EventReadOnlyDTO>>builder()
                .status(HttpStatus.OK)
                .data(events)
                .build();

        // Return the response entity with HTTP 200 status
        return new ResponseEntity<>(successResponseDTO, HttpStatus.OK);
    }


    /**
     * Endpoint to retrieve paginated and filtered events based on the provided filter criteria.
     *
     * @param filterDTO A DTO containing filter criteria such as event type, date range, etc.
     * @param page      The page number for pagination (default is 0).
     * @param size      The number of events per page (default is 10).
     * @return A ResponseEntity containing a paginated list of filtered events wrapped in a SuccessResponseDTO.
     */
    @PostMapping("/filters/paginated")
    public ResponseEntity<SuccessResponseDTO<Paginated<EventReadOnlyDTO>>> getPaginatedFilteredEvents(
            @RequestBody EventFilterDTO filterDTO,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        Paginated<EventReadOnlyDTO> events = eventService.getPaginatedFilteredEvents(filterDTO, page, size);
        SuccessResponseDTO<Paginated<EventReadOnlyDTO>> responseDTO = SuccessResponseDTO.<Paginated<EventReadOnlyDTO>>builder()
                .status(HttpStatus.OK)
                .data(events)
                .build();
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    /**
     * Endpoint to retrieve a list of filtered events based on the provided filter criteria.
     *
     * @param filterDTO A DTO containing filter criteria such as event type, date range, etc.
     * @return A ResponseEntity containing a list of filtered events wrapped in a SuccessResponseDTO.
     */
    @PostMapping("/filters")
    public ResponseEntity<SuccessResponseDTO<List<EventReadOnlyDTO>>> getFilteredEvents(
            @RequestBody @Valid EventFilterDTO filterDTO
    ) {
        List<EventReadOnlyDTO> events = eventService.getFilteredEvents(filterDTO);
        SuccessResponseDTO<List<EventReadOnlyDTO>> responseDTO = SuccessResponseDTO.<List<EventReadOnlyDTO>>builder()
                .status(HttpStatus.OK)
                .data(events)
                .build();
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
}
