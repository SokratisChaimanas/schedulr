package gr.myprojects.schedulr.dto.user;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class UserLoginDTO {
    private String username;
    private String email;
    private String password;
}
