package gr.myprojects.schedulr.dto.event;

import gr.myprojects.schedulr.core.enums.Status;
import gr.myprojects.schedulr.dto.comment.CommentReadOnlyDTO;
import gr.myprojects.schedulr.dto.user.UserReadOnlyDTO;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class EventReadOnlyDTO {
    private Status status;
    private String uuid;
    private String title;
    private String description;
    private LocalDateTime date;
    private ImageAttachmentReadOnlyDTO imageAttachmentReadOnlyDTO;
    private UserReadOnlyDTO ownerReadOnlyDTO;
    private Double price;
    private List<CommentReadOnlyDTO> commentsList;
}
