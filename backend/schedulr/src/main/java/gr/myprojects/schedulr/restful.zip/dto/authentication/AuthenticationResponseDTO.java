package gr.myprojects.schedulr.dto.authentication;

import gr.myprojects.schedulr.core.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AuthenticationResponseDTO {
    private String token;
    private String uuid;
    private Role role;
}
