package gr.myprojects.schedulr.dto.comment;

import jakarta.validation.constraints.NotEmpty;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class CommentCreateDTO {

    @NotEmpty(message = "Comment description should not be empty")
    private String description;

    @NotEmpty(message = "User uuid should not be empty")
    private String userUuid;

    @NotEmpty(message = "Event uuid should not be empty")
    private String eventUuid;
}
