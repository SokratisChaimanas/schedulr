package gr.myprojects.schedulr.dto.event;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class ImageAttachmentReadOnlyDTO {
    private String filepath;
    private String savedName;
    private String extension;
}
