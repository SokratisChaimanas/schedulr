package gr.myprojects.schedulr.dto.comment;

import gr.myprojects.schedulr.dto.user.UserReadOnlyDTO;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class CommentReadOnlyDTO {
    private String uuid;
    private String description;
    private String authorUsername;
    private String eventTitle;
    private String eventUuid;
    private Boolean isDeleted;
}
