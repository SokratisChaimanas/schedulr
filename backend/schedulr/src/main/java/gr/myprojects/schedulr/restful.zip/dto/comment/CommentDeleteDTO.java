package gr.myprojects.schedulr.dto.comment;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class CommentDeleteDTO {
    private String commentUuid;
    private String userUuid;
}
