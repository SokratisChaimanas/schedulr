package gr.myprojects.schedulr.dto.user;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class UserReadOnlyDTO {
    private String uuid;
    private String username;
}
