package gr.myprojects.schedulr.dto.event;

import gr.myprojects.schedulr.core.enums.Category;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EventFilterDTO {
    private LocalDate startDate; // Start date for filtering events.
    private LocalDate endDate;   // End date for filtering events.
    private String location;     // Filter by location.
    private Double minPrice;     // Minimum price filter.
    private Double maxPrice;     // Maximum price filter.
    private Category category;   // Category of the event (e.g., "Workshop", "Conference").
    private String title;        // Title of the event (optional, supports partial match).
}
