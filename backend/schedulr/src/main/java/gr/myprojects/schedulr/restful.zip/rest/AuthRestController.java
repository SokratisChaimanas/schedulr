package gr.myprojects.schedulr.rest;

import gr.myprojects.schedulr.authentication.AuthenticationService;
import gr.myprojects.schedulr.core.exceptions.AppObjectAlreadyExistsException;
import gr.myprojects.schedulr.core.exceptions.AppServerException;
import gr.myprojects.schedulr.core.exceptions.UserNotAuthorizedException;
import gr.myprojects.schedulr.core.exceptions.ValidationException;
import gr.myprojects.schedulr.dto.authentication.AuthenticationRequestDTO;
import gr.myprojects.schedulr.dto.authentication.AuthenticationResponseDTO;
import gr.myprojects.schedulr.dto.response.SuccessResponseDTO;
import gr.myprojects.schedulr.dto.user.UserReadOnlyDTO;
import gr.myprojects.schedulr.dto.user.UserRegisterDTO;
import gr.myprojects.schedulr.repository.UserRepository;
import gr.myprojects.schedulr.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthRestController {
    private final UserService userService;
    private final AuthenticationService authenticationService;
//    private final Logger LOGGER = LoggerFactory.getLogger(AuthRestController.class);

    @PostMapping("/register")
    public ResponseEntity<SuccessResponseDTO<UserReadOnlyDTO>> registerUser(
            @Valid @RequestBody UserRegisterDTO userRegisterDTO,
            BindingResult bindingResult
    ) throws ValidationException, AppServerException, AppObjectAlreadyExistsException {
        if (bindingResult.hasErrors()) {
            throw new ValidationException("User", bindingResult);
        }

        UserReadOnlyDTO readOnlyDTO = userService.registerUser(userRegisterDTO);

        SuccessResponseDTO<UserReadOnlyDTO> responseDTO = SuccessResponseDTO.<UserReadOnlyDTO>builder()
                .status(HttpStatus.CREATED)
                .data(readOnlyDTO)
                .build();
        return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<SuccessResponseDTO<AuthenticationResponseDTO>> loginUser(
            @RequestBody AuthenticationRequestDTO authenticationRequestDTO) throws UserNotAuthorizedException {
        AuthenticationResponseDTO authenticationResponseDTO = authenticationService.authenticate(authenticationRequestDTO);

        SuccessResponseDTO<AuthenticationResponseDTO> successResponseDTO = SuccessResponseDTO.<AuthenticationResponseDTO>builder()
                .status(HttpStatus.OK)
                .data(authenticationResponseDTO)
                .build();

        return new ResponseEntity<>(successResponseDTO, HttpStatus.OK);
    }
}
